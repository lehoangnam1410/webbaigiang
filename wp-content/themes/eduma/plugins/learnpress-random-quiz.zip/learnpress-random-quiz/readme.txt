=== LearnPress - Random questions quiz ===

== Changelog ==

= 4.0.3 (2023-01-17) =
~ Fixed: error if set "Random Questions" > 16.
~ Fixed: error if set "Random Questions" question = 0.

= 4.0.2 =
~ Added: feature questions bank.

= 4.0.1 =
~ Fixed: error random question when option "random question" turn off

= 4.0.0 =
~ Fixed compatible LP4

= 3.1.2 =
~ Fixed check null variable

= 3.1.1 =
~ Fixed bug: not start the quiz with the first question after randomizing.

= 3.1 =
~ Compatyible with frontend editor addon


= 3.0.0 =
+ Initial released.
