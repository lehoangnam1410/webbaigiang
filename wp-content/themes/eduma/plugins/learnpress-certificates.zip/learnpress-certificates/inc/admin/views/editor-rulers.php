<div id="cert-design-line-horizontal" class="cert-design-line horizontal"></div>
<div id="cert-design-line-vertical" class="cert-design-line vertical"></div>
<div id="cert-rulers">
    <div class="cert-ruler-horizontal">
        <span class="ruler-magnitude horizontal twenty-five"></span>
        <span class="ruler-magnitude horizontal fifty"></span>
        <span class="ruler-magnitude horizontal seventy-five"></span>
    </div>
    <div class="cert-ruler-horizontal bottom">
        <span class="ruler-magnitude horizontal twenty-five"></span>
        <span class="ruler-magnitude horizontal fifty"></span>
        <span class="ruler-magnitude horizontal seventy-five"></span>
    </div>
    <div class="cert-ruler-vertical">
        <span class="ruler-magnitude vertical twenty-five"></span>
        <span class="ruler-magnitude vertical fifty"></span>
        <span class="ruler-magnitude vertical seventy-five"></span>
    </div>
    <div class="cert-ruler-vertical right">
        <span class="ruler-magnitude vertical twenty-five"></span>
        <span class="ruler-magnitude vertical fifty"></span>
        <span class="ruler-magnitude vertical seventy-five"></span>
    </div>
</div>