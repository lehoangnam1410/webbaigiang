=== Builderpress - WordPress LMS Plugin ===
Contributors: thimpress
Donate link:
Tags: elearning, education, course, lms, learning management system
Requires at least: 5.8
Tested up to: 6.2
Requires PHP: 7.0
Stable tag: 2.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A WordPress LMS Plugin to create WordPress Learning Management System. Turn your WordPress to LMS WordPress Website with Courses, Lessons, Quizzes & more.

== Description ==

== Changelog ==

= 2.0.0 (2023-05-23) =
~ Optimize: code load widgets.
