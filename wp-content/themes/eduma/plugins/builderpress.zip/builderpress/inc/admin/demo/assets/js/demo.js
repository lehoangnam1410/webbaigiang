(function ($) {
    "use strict";

    $(document).ready(function () {

    });

})(jQuery);