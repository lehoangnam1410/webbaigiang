<?php
/**
 * Template for displaying default template Demo element.
 *
 * This template can be overridden by copying it to yourtheme/builderpress/demo/layout-1.php.
 *
 * @author      ThimPress
 * @package     BuilderPress/Templates
 * @version     1.0.0
 * @author      Thimpress, vinhnq
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;