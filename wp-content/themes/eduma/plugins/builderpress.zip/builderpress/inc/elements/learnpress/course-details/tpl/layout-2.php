<?php
/**
 * Template for displaying default template Learnpress Course Details element layout 2.
 *
 * This template can be overridden by copying it to yourtheme/builderpress/course-details/layout-2.php.
 *
 * @author      ThimPress
 * @package     BuilderPress/Templates
 * @version     1.0.0
 * @author      Thimpress, leehld
 */

/**
 * Prevent loading this file directly
 */
defined( 'ABSPATH' ) || exit;