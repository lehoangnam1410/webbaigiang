=== LearnPress - Mycred ===
Contributors: thimpress
Donate link:
Tags: lms, elearning, e-learning, learning management system, education, course, courses, quiz, quizzes, questions, bank transfer, offline, payment
Requires at least: 5.8
Requires PHP: 7.0
Tested up to: 6
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Screenshots ==

== Changelog ==

= 4.0.1 =
+ Update hook.

= 4.0.0 =
+ Fix compatible LP4.
