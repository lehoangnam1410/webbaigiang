=== LearnPress - Stripe ===
Contributors: thimpress, tungnx89, nhamdv, hungkv.
Donate link:
Tags: elearning, education, course, lms, learning management system
Requires at least: 5.6
Tested up to: 5.7
Requires PHP: 7.0
Stable tag: 4.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Change log ==

= 4.0.1 =
~ Fix minor bug.

= 4.0.0 =
~ Fix compatible.
