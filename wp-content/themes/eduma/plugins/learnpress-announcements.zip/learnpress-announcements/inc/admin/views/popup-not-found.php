<?php
/**
 * Admin popup not found course view.
 *
 * @since 3.0.0
 */
?>

<li class="lp-not-found">
	<?php esc_html_e( 'Course is empty', 'learnpress-announcements' ) ?>
</li>